export class Employee {
    public eid:string;
    public ename:string;
    public joindate:Date;
    public designation:string;
    public salary:number

}
