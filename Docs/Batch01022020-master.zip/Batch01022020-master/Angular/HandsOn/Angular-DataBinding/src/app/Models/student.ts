export class Student {
    Sid:number;
    Sname:string;
    DOB:Date;
    Std:string;
    Age:number;
}
