export class Student {
    public sid:number;
    public sname:string;
    public std:string;
    public age:number
}
