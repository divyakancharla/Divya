export class User {
    public uname:string;
    public pwd:string;
}
