﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnArrays
{
    class Demo2
    {
        static void Main()
        {
            double[] d = new double[3] { 12.2, 14.4, 45.6 };
            char[] ch = { 'a', 'b', '1', '3' };
            object[] ob = new object[4] { "Rohan", 23, 12000, true };
            string[] n = { "Rose", "Lilly", "Jasmine" };
        }
    }
}
