Create procedure GetEmployees
as
Begin
     Select *
     from Employees
End