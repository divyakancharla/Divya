-- TB_CUSTOMER

insert into TB_CUSTOMER
(Customer_Id,First_Name,Last_Name,Gender,Location,
Zipcode,User_Name,Password)
values
(1,'Ramesh','Shetty','M','Blore',560078,'ram_esh','ram_esh@123')

insert into TB_CUSTOMER
(Customer_Id,First_Name,Last_Name,Gender,Location,
Zipcode,User_Name,Password)
values
(2,'Geeta','Shah','F','Chennai',450012,'Geeta_S','geetaS@123')