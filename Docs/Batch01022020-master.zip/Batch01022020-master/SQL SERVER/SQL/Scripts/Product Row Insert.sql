-- product table

insert into TB_PRODUCT
(Product_Id,Product_Name,Description,
Unit_Price,Stock,Category_Id)
values
(10,'Lumia 510','New Smart Phone from Nokia',15000,3500,1)
insert into TB_PRODUCT
(Product_Id,Product_Name,Description,
Unit_Price,Stock,Category_Id)
values
(20,'Lumia 1015','Latest Smart Phone from Nokia',45000,500,1)

insert into TB_PRODUCT
(Product_Id,Product_Name,Description,
Unit_Price,Stock,Category_Id)
values
(30,'LCD TV','32 Inch Flat Screen TV',45500,200,2)
insert into TB_PRODUCT
(Product_Id,Product_Name,Description,
Unit_Price,Stock,Category_Id)
values
(40,'Fridge','LG 250 liters Fridge',18000,500,2)

insert into TB_PRODUCT
(Product_Id,Product_Name,Description,
Unit_Price,Stock,Category_Id)
values
(50,'Chair','Bambo Chair',800,1200,3)
insert into TB_PRODUCT
(Product_Id,Product_Name,Description,
Unit_Price,Stock,Category_Id)
values
(60,'Dining Table','Revolving Dining Table',2500,50,3)

insert into TB_PRODUCT
(Product_Id,Product_Name,Description,
Unit_Price,Stock,Category_Id)
values
(70,'Mixer','Kilash Mixer and Grinder',2000,200,4)
insert into TB_PRODUCT
(Product_Id,Product_Name,Description,
Unit_Price,Stock,Category_Id)
values
(80,'Oven IC200','Onida Convention Oven',4500,300,4)
