-- Category Table

create table TB_CATEGORY
(
Category_Id int not null,
Category_Name char(25) not null,
[Description] varchar(500)
)