-- Create database command (single line coomand)
create database Trng
go

-- delete the database
drop database Trng
go
 
/*
Multi Line Cooment
*/