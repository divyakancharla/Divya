-- Union

select pub_id,pub_name from publishers
union
select au_id,au_fname from authors