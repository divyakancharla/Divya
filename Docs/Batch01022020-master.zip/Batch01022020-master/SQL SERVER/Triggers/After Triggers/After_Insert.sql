create trigger Emp_insert1
on Emp
after insert
aas
print 'Record Added'
go
