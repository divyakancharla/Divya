declare @id int
set @id=1
while(@id<100)
begin
print @id
set @id=@id+1
end